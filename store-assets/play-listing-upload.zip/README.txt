IAMovies — Play Console main store listing assets (2026-09-25)
================================================================

PHONE screenshots (Main store listing > Phone > Screenshots) - upload all 5:
  phone/01-home.png        1080x1920  home: Trending / New / Discover + poster grid
  phone/02-series.png      1080x1920  series library
  phone/03-watch.png       1080x1920  full-screen vertical episode feed
  phone/04-subscribe.png   1080x1920  plans (captured in APP mode - no payment UI)
  phone/05-browse.png      1080x1920  episode picker sheet open

TABLET screenshots (Main store listing > Tablet) - upload all 4 (only required if
tablets stay in Device availability; t1-home excluded because the 7-poster grid
left the bottom half of the frame empty):
  tablet/t2-series.png     1600x2560
  tablet/t3-watch.png      1600x2560
  tablet/t4-subscribe.png  1600x2560
  tablet/t5-browse.png     1600x2560

FEATURE GRAPHIC (1024x500, required):
  feature-graphic.jpg

HIGH-RES ICON (512x512 PNG, required):
  app-icon-512.png

Notes
- Captured from the LIVE site after the last deploy (2ea5745) so they match the
  app exactly: 3 header tabs, no Premium tab, no Continue Watching row, and NO
  external payment flow.
- Every file is under Play's 8 MB limit.
- ChromeOS / TV / wear screenshots only needed if those device types stay enabled
  in Device availability.
